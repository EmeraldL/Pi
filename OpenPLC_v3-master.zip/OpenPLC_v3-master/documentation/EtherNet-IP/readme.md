Here you will find all documentation related to the EtherNet/IP implementation on OpenPLC
